import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class Todo {
  final String title;
  final bool isCompleted;

  Todo({required this.title, this.isCompleted = false});
}

class TodoListEvent {}

class AddTodoEvent extends TodoListEvent {
  final Todo todo;

  AddTodoEvent(this.todo);
}

class RemoveTodoEvent extends TodoListEvent {
  final Todo todo;

  RemoveTodoEvent(this.todo);
}

class CompleteTodoEvent extends TodoListEvent {
  final Todo todo;

  CompleteTodoEvent(this.todo);
}

class EditTodoEvent extends TodoListEvent {
  final Todo oldTodo;
  final Todo newTodo;

  EditTodoEvent({required this.oldTodo, required this.newTodo});
}

class TodoListState {
  final List<Todo> todos;

  TodoListState({this.todos = const []});

  TodoListState copyWith({List<Todo>? todos}) {
    return TodoListState(todos: todos ?? this.todos);
  }
}

class TodoListBloc extends Bloc<TodoListEvent, TodoListState> {
  TodoListBloc() : super(TodoListState(todos: []));

  @override
  Stream<TodoListState> mapEventToState(TodoListEvent event) {
    if (event is AddTodoEvent) {
      return Stream.of(state.copyWith(todos: [...state.todos, event.todo]));
    } else if (event is RemoveTodoEvent) {
      return Stream.of(state.copyWith(todos: state.todos.where((todo) => todo != event.todo)));
    } else if (event is CompleteTodoEvent) {
      return Stream.of(state.copyWith(todos: state.todos.map((todo) => todo == event.todo ? todo.copyWith(isCompleted: true) : todo)));
    } else if (event is EditTodoEvent) {
      return Stream.of(state.copyWith(
        todos: state.todos.map((todo) => todo == event.oldTodo ? event.newTodo : todo),
      ));
    }
    return Stream.empty();
  }
}

class TodoListPage extends StatefulWidget {
  @override
  _TodoListPageState createState() => _TodoListPageState();
}

class _TodoListPageState extends State<TodoListPage> {
  final TextEditingController _titleController = TextEditingController();

  late Todo _editedTodo;
  bool _isEdit = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('To-Do List'),
      ),
      body: BlocBuilder<TodoListBloc, TodoListState>(
        builder: (context, state) {
          return ListView.builder(
            itemCount: state.todos.length,
            itemBuilder: (context, index) {
              final todo = state.todos[index];
              return ListTile(
                title: Text(todo.title),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Checkbox(
                      value: todo.isCompleted,
                      onChanged: (value) {
                        context.bloc<TodoListBloc>().add(CompleteTodoEvent(todo));
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.edit),
                      onPressed: () {
                        _editTodo(todo);
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.delete),
                      onPressed: () {
                        context.bloc<TodoListBloc>().add(RemoveTodoEvent(todo));
                      },
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            _isEdit = false;
            _titleController.clear();
          });
          showDialog(
            context: context,
            builder: (context) {
              return AlertDialog(
                title: Text(_isEdit ? 'Edit Todo' : 'Add Todo'),
                content: TextField(
                  controller: _titleController,
                ),
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text('Cancel'),
                  ),
                  TextButton(
                    onPressed: () {
                      if (_isEdit) {
                        context.bloc<TodoListBloc>().add(
                          EditTodoEvent(
                            oldTodo: _editedTodo,
                            newTodo: Todo(title: _titleController.text),
                          ),
                        );
                      } else {
                        context.bloc<TodoListBloc>().add(
                          AddTodoEvent(Todo(title: _titleController.text)),
                        );
                      }
                      Navigator.pop(context);
                    },
                    child: Text(_isEdit ? 'Save' : 'Add'),
                  ),
                ],
              );
            },
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
  void _editTodo(Todo todo) {
    setState(() {
      _isEdit = true;
      _editedTodo = todo;
      _titleController.text = todo.title;
    });
    showDialog(
    );
  }
}

void main() {
  runApp(BlocProvider(
    create: (context) => TodoListBloc(),
    child: MaterialApp(
      home: TodoListPage(),
    ),
  ));
}